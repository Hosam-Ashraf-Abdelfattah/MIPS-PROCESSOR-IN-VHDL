/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/ahmed/Desktop/project hdl/new_processor/fetchingg.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );
char *ieee_p_3620187407_sub_436279890_3965413181(char *, char *, char *, char *, int );


static void work_a_1627838639_3212880686_p_0(char *t0)
{
    char t14[16];
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned int t15;
    unsigned int t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 992U);
    t3 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    t1 = (t0 + 5496);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(46, ng0);
    t1 = (t0 + 9496);
    t6 = (t0 + 5624);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 32U);
    xsi_driver_first_trans_fast(t6);
    goto LAB3;

LAB5:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 2632U);
    t5 = *((char **)t2);
    t4 = *((unsigned char *)t5);
    t11 = (t4 == (unsigned char)2);
    if (t11 != 0)
        goto LAB7;

LAB9:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t1 = (t0 + 5624);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t1);

LAB8:    goto LAB3;

LAB7:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 1352U);
    t6 = *((char **)t2);
    t12 = *((unsigned char *)t6);
    t13 = (t12 == (unsigned char)2);
    if (t13 != 0)
        goto LAB10;

LAB12:    xsi_set_current_line(53, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 5624);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast(t1);

LAB11:    goto LAB8;

LAB10:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 3112U);
    t7 = *((char **)t2);
    t2 = (t0 + 9356U);
    t8 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t14, t7, t2, 4);
    t9 = (t14 + 12U);
    t15 = *((unsigned int *)t9);
    t16 = (1U * t15);
    t17 = (32U != t16);
    if (t17 == 1)
        goto LAB13;

LAB14:    t10 = (t0 + 5624);
    t18 = (t10 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t8, 32U);
    xsi_driver_first_trans_fast(t10);
    goto LAB11;

LAB13:    xsi_size_not_matching(32U, t16, 0);
    goto LAB14;

}

static void work_a_1627838639_3212880686_p_1(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(73, ng0);

LAB3:    t2 = (t0 + 3112U);
    t3 = *((char **)t2);
    t2 = (t0 + 9356U);
    t4 = ieee_p_3620187407_sub_436279890_3965413181(IEEE_P_3620187407, t1, t3, t2, 4);
    t5 = (t1 + 12U);
    t6 = *((unsigned int *)t5);
    t7 = (1U * t6);
    t8 = (32U != t7);
    if (t8 == 1)
        goto LAB5;

LAB6:    t9 = (t0 + 5688);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t4, 32U);
    xsi_driver_first_trans_fast_port(t9);

LAB2:    t14 = (t0 + 5512);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t7, 0);
    goto LAB6;

}

static void work_a_1627838639_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    int t13;
    char *t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t53;
    int t55;
    char *t56;
    int t58;
    char *t59;
    int t61;
    char *t62;
    int t64;
    char *t65;
    int t67;
    char *t68;
    int t70;
    char *t71;
    int t73;
    char *t74;
    int t76;
    char *t77;
    int t79;
    char *t80;
    int t82;
    char *t83;
    int t85;
    char *t86;
    int t88;
    char *t89;
    int t91;
    char *t92;
    int t94;
    char *t95;
    int t97;
    char *t98;
    int t100;
    char *t101;
    int t103;
    char *t104;
    int t106;
    char *t107;
    int t109;
    char *t110;
    int t112;
    char *t113;
    int t115;
    char *t116;
    int t118;
    char *t119;
    int t121;
    char *t122;
    int t124;
    char *t125;
    int t127;
    char *t128;
    int t130;
    char *t131;
    int t133;
    char *t134;
    int t136;
    char *t137;
    int t139;
    char *t140;
    char *t142;
    char *t143;
    char *t144;
    char *t145;
    char *t146;

LAB0:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 3112U);
    t2 = *((char **)t1);
    t1 = (t0 + 9528);
    t4 = xsi_mem_cmp(t1, t2, 32U);
    if (t4 == 1)
        goto LAB3;

LAB50:    t5 = (t0 + 9560);
    t7 = xsi_mem_cmp(t5, t2, 32U);
    if (t7 == 1)
        goto LAB4;

LAB51:    t8 = (t0 + 9592);
    t10 = xsi_mem_cmp(t8, t2, 32U);
    if (t10 == 1)
        goto LAB5;

LAB52:    t11 = (t0 + 9624);
    t13 = xsi_mem_cmp(t11, t2, 32U);
    if (t13 == 1)
        goto LAB6;

LAB53:    t14 = (t0 + 9656);
    t16 = xsi_mem_cmp(t14, t2, 32U);
    if (t16 == 1)
        goto LAB7;

LAB54:    t17 = (t0 + 9688);
    t19 = xsi_mem_cmp(t17, t2, 32U);
    if (t19 == 1)
        goto LAB8;

LAB55:    t20 = (t0 + 9720);
    t22 = xsi_mem_cmp(t20, t2, 32U);
    if (t22 == 1)
        goto LAB9;

LAB56:    t23 = (t0 + 9752);
    t25 = xsi_mem_cmp(t23, t2, 32U);
    if (t25 == 1)
        goto LAB10;

LAB57:    t26 = (t0 + 9784);
    t28 = xsi_mem_cmp(t26, t2, 32U);
    if (t28 == 1)
        goto LAB11;

LAB58:    t29 = (t0 + 9816);
    t31 = xsi_mem_cmp(t29, t2, 32U);
    if (t31 == 1)
        goto LAB12;

LAB59:    t32 = (t0 + 9848);
    t34 = xsi_mem_cmp(t32, t2, 32U);
    if (t34 == 1)
        goto LAB13;

LAB60:    t35 = (t0 + 9880);
    t37 = xsi_mem_cmp(t35, t2, 32U);
    if (t37 == 1)
        goto LAB14;

LAB61:    t38 = (t0 + 9912);
    t40 = xsi_mem_cmp(t38, t2, 32U);
    if (t40 == 1)
        goto LAB15;

LAB62:    t41 = (t0 + 9944);
    t43 = xsi_mem_cmp(t41, t2, 32U);
    if (t43 == 1)
        goto LAB16;

LAB63:    t44 = (t0 + 9976);
    t46 = xsi_mem_cmp(t44, t2, 32U);
    if (t46 == 1)
        goto LAB17;

LAB64:    t47 = (t0 + 10008);
    t49 = xsi_mem_cmp(t47, t2, 32U);
    if (t49 == 1)
        goto LAB18;

LAB65:    t50 = (t0 + 10040);
    t52 = xsi_mem_cmp(t50, t2, 32U);
    if (t52 == 1)
        goto LAB19;

LAB66:    t53 = (t0 + 10072);
    t55 = xsi_mem_cmp(t53, t2, 32U);
    if (t55 == 1)
        goto LAB20;

LAB67:    t56 = (t0 + 10104);
    t58 = xsi_mem_cmp(t56, t2, 32U);
    if (t58 == 1)
        goto LAB21;

LAB68:    t59 = (t0 + 10136);
    t61 = xsi_mem_cmp(t59, t2, 32U);
    if (t61 == 1)
        goto LAB22;

LAB69:    t62 = (t0 + 10168);
    t64 = xsi_mem_cmp(t62, t2, 32U);
    if (t64 == 1)
        goto LAB23;

LAB70:    t65 = (t0 + 10200);
    t67 = xsi_mem_cmp(t65, t2, 32U);
    if (t67 == 1)
        goto LAB24;

LAB71:    t68 = (t0 + 10232);
    t70 = xsi_mem_cmp(t68, t2, 32U);
    if (t70 == 1)
        goto LAB25;

LAB72:    t71 = (t0 + 10264);
    t73 = xsi_mem_cmp(t71, t2, 32U);
    if (t73 == 1)
        goto LAB26;

LAB73:    t74 = (t0 + 10296);
    t76 = xsi_mem_cmp(t74, t2, 32U);
    if (t76 == 1)
        goto LAB27;

LAB74:    t77 = (t0 + 10328);
    t79 = xsi_mem_cmp(t77, t2, 32U);
    if (t79 == 1)
        goto LAB28;

LAB75:    t80 = (t0 + 10360);
    t82 = xsi_mem_cmp(t80, t2, 32U);
    if (t82 == 1)
        goto LAB29;

LAB76:    t83 = (t0 + 10392);
    t85 = xsi_mem_cmp(t83, t2, 32U);
    if (t85 == 1)
        goto LAB30;

LAB77:    t86 = (t0 + 10424);
    t88 = xsi_mem_cmp(t86, t2, 32U);
    if (t88 == 1)
        goto LAB31;

LAB78:    t89 = (t0 + 10456);
    t91 = xsi_mem_cmp(t89, t2, 32U);
    if (t91 == 1)
        goto LAB32;

LAB79:    t92 = (t0 + 10488);
    t94 = xsi_mem_cmp(t92, t2, 32U);
    if (t94 == 1)
        goto LAB33;

LAB80:    t95 = (t0 + 10520);
    t97 = xsi_mem_cmp(t95, t2, 32U);
    if (t97 == 1)
        goto LAB34;

LAB81:    t98 = (t0 + 10552);
    t100 = xsi_mem_cmp(t98, t2, 32U);
    if (t100 == 1)
        goto LAB35;

LAB82:    t101 = (t0 + 10584);
    t103 = xsi_mem_cmp(t101, t2, 32U);
    if (t103 == 1)
        goto LAB36;

LAB83:    t104 = (t0 + 10616);
    t106 = xsi_mem_cmp(t104, t2, 32U);
    if (t106 == 1)
        goto LAB37;

LAB84:    t107 = (t0 + 10648);
    t109 = xsi_mem_cmp(t107, t2, 32U);
    if (t109 == 1)
        goto LAB38;

LAB85:    t110 = (t0 + 10680);
    t112 = xsi_mem_cmp(t110, t2, 32U);
    if (t112 == 1)
        goto LAB39;

LAB86:    t113 = (t0 + 10712);
    t115 = xsi_mem_cmp(t113, t2, 32U);
    if (t115 == 1)
        goto LAB40;

LAB87:    t116 = (t0 + 10744);
    t118 = xsi_mem_cmp(t116, t2, 32U);
    if (t118 == 1)
        goto LAB41;

LAB88:    t119 = (t0 + 10776);
    t121 = xsi_mem_cmp(t119, t2, 32U);
    if (t121 == 1)
        goto LAB42;

LAB89:    t122 = (t0 + 10808);
    t124 = xsi_mem_cmp(t122, t2, 32U);
    if (t124 == 1)
        goto LAB43;

LAB90:    t125 = (t0 + 10840);
    t127 = xsi_mem_cmp(t125, t2, 32U);
    if (t127 == 1)
        goto LAB44;

LAB91:    t128 = (t0 + 10872);
    t130 = xsi_mem_cmp(t128, t2, 32U);
    if (t130 == 1)
        goto LAB45;

LAB92:    t131 = (t0 + 10904);
    t133 = xsi_mem_cmp(t131, t2, 32U);
    if (t133 == 1)
        goto LAB46;

LAB93:    t134 = (t0 + 10936);
    t136 = xsi_mem_cmp(t134, t2, 32U);
    if (t136 == 1)
        goto LAB47;

LAB94:    t137 = (t0 + 10968);
    t139 = xsi_mem_cmp(t137, t2, 32U);
    if (t139 == 1)
        goto LAB48;

LAB95:
LAB49:    xsi_set_current_line(172, ng0);
    t1 = (t0 + 12472);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);

LAB2:    t1 = (t0 + 5528);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(80, ng0);
    t140 = (t0 + 11000);
    t142 = (t0 + 5752);
    t143 = (t142 + 56U);
    t144 = *((char **)t143);
    t145 = (t144 + 56U);
    t146 = *((char **)t145);
    memcpy(t146, t140, 32U);
    xsi_driver_first_trans_fast(t142);
    goto LAB2;

LAB4:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 11032);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB5:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 11064);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB6:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 11096);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB7:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 11128);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB8:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 11160);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB9:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 11192);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB10:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 11224);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB11:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 11256);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB12:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 11288);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB13:    xsi_set_current_line(100, ng0);
    t1 = (t0 + 11320);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB14:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 11352);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB15:    xsi_set_current_line(104, ng0);
    t1 = (t0 + 11384);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB16:    xsi_set_current_line(106, ng0);
    t1 = (t0 + 11416);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB17:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 11448);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB18:    xsi_set_current_line(110, ng0);
    t1 = (t0 + 11480);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB19:    xsi_set_current_line(112, ng0);
    t1 = (t0 + 11512);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB20:    xsi_set_current_line(114, ng0);
    t1 = (t0 + 11544);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB21:    xsi_set_current_line(116, ng0);
    t1 = (t0 + 11576);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB22:    xsi_set_current_line(118, ng0);
    t1 = (t0 + 11608);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB23:    xsi_set_current_line(120, ng0);
    t1 = (t0 + 11640);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB24:    xsi_set_current_line(122, ng0);
    t1 = (t0 + 11672);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB25:    xsi_set_current_line(124, ng0);
    t1 = (t0 + 11704);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB26:    xsi_set_current_line(126, ng0);
    t1 = (t0 + 11736);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB27:    xsi_set_current_line(128, ng0);
    t1 = (t0 + 11768);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB28:    xsi_set_current_line(130, ng0);
    t1 = (t0 + 11800);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB29:    xsi_set_current_line(132, ng0);
    t1 = (t0 + 11832);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB30:    xsi_set_current_line(134, ng0);
    t1 = (t0 + 11864);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB31:    xsi_set_current_line(136, ng0);
    t1 = (t0 + 11896);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB32:    xsi_set_current_line(138, ng0);
    t1 = (t0 + 11928);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB33:    xsi_set_current_line(140, ng0);
    t1 = (t0 + 11960);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB34:    xsi_set_current_line(142, ng0);
    t1 = (t0 + 11992);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB35:    xsi_set_current_line(144, ng0);
    t1 = (t0 + 12024);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB36:    xsi_set_current_line(146, ng0);
    t1 = (t0 + 12056);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB37:    xsi_set_current_line(148, ng0);
    t1 = (t0 + 12088);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB38:    xsi_set_current_line(150, ng0);
    t1 = (t0 + 12120);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB39:    xsi_set_current_line(152, ng0);
    t1 = (t0 + 12152);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB40:    xsi_set_current_line(154, ng0);
    t1 = (t0 + 12184);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB41:    xsi_set_current_line(156, ng0);
    t1 = (t0 + 12216);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB42:    xsi_set_current_line(158, ng0);
    t1 = (t0 + 12248);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB43:    xsi_set_current_line(160, ng0);
    t1 = (t0 + 12280);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB44:    xsi_set_current_line(162, ng0);
    t1 = (t0 + 12312);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB45:    xsi_set_current_line(164, ng0);
    t1 = (t0 + 12344);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB46:    xsi_set_current_line(166, ng0);
    t1 = (t0 + 12376);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB47:    xsi_set_current_line(168, ng0);
    t1 = (t0 + 12408);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB48:    xsi_set_current_line(170, ng0);
    t1 = (t0 + 12440);
    t3 = (t0 + 5752);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);
    goto LAB2;

LAB96:;
}

static void work_a_1627838639_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(179, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 5);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5816);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 6U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(180, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5880);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 5U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(181, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 20);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5944);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 5U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(182, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 25);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 6008);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 5U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(183, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 6072);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 6U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(184, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 6136);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 16U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(185, ng0);
    t1 = (t0 + 3272U);
    t2 = *((char **)t1);
    t1 = (t0 + 6200);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 5544);
    *((int *)t1) = 1;

LAB1:    return;
}


extern void work_a_1627838639_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1627838639_3212880686_p_0,(void *)work_a_1627838639_3212880686_p_1,(void *)work_a_1627838639_3212880686_p_2,(void *)work_a_1627838639_3212880686_p_3};
	xsi_register_didat("work_a_1627838639_3212880686", "isim/mips_test_isim_beh.exe.sim/work/a_1627838639_3212880686.didat");
	xsi_register_executes(pe);
}
